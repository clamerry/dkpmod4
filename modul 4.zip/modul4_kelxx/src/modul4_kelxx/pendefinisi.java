/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul4_kelxx;

/**
 *
 * @author Erika
 */
public class pendefinisi {
    public void greeting(){
        System.out.println("Hai, saya method dari class pendefinisi. Salam kenal :)");
    }
    public void kelompok(String kelompok){
        System.out.println(kelompok);
    }
    public String kenalan (String nama, String hobi){
        return "Hai, Nama saya " + nama + " hobi saya " + hobi;
    }
}

